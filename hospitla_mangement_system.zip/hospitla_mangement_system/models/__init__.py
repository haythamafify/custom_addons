# -*- coding: utf-8 -*-

from . import hospital_patient
from . import hospital_appointment
from . import hospital_medicine
from . import hospital_doctor
from . import hospital_departments
from . import medical_record
from . import hospital_invoice
from . import medicine_category
from . import hospital_admission
from . import hospital_lab_test
from . import hospital_operation_room
from . import hospital_surgery
from . import hospital_nurse
from . import hospital_staff
from . import hospital_lab_appointment
from . import hospital_monthly_report

